# AI Agent — Local Setup Guide (v3)

A local, tool-using AI agent: a model served by LM Studio, wrapped in a
FastAPI + LangChain harness, with ChromaDB vector memory, SQLite conversation
persistence, and a React chat UI.

## Architecture

```
[UI Machine :3000]  ──WebSocket (token)──▶  [Windows Server :8000]
                                                  │
                                          FastAPI + LangChain
                                                  │
                          ┌───────────────┬───────┴───────┬───────────────┐
                      ChatOpenAI       ChromaDB        SQLite          workspace/
                    (via LM Studio)  (vector mem)   (chat history)   (file sandbox)
```

## What's new in v3

**Tier 1 — security**
- Token auth on the WebSocket handshake and on data HTTP routes (`API_TOKEN`).
- File tools confined to a `WORKSPACE_ROOT` sandbox via an allowlist.
- Human-in-the-loop: `run_command` and `run_python` require UI approval.

**Tier 2 — reliability**
- Cancellation: a running agent turn can be stopped mid-stream.
- `/health` verifies the LM Studio server is actually reachable.
- Structured logging to a rotating file (`logs/agent.log`) plus console.
- SQLite conversation persistence (`store.py`) — replaces v2's JSON files.

**Tier 3 — capability**
- File upload over the WebSocket into the workspace.
- Automatic memory: conversations are summarised into long-term memory.
- Live tool-output streaming, shown line-by-line in the UI.
- Optional fast/main model routing per turn (`FAST_MODEL`).

**New coding tool** — `run_python` executes a Python 3 snippet in the workspace.

Model serving: LM Studio exposes an OpenAI-compatible API, so the harness uses
`ChatOpenAI` pointed at it. Context length is set in the LM Studio app when you
load the model.

---

## Step 1 — Windows Server: Install LM Studio

1. Download from https://lmstudio.ai and install.
2. In the **Search** tab, download two models:
   - A tool-calling chat model — e.g. `Qwen2.5-7B-Instruct` (GGUF).
   - An embedding model — `text-embedding-nomic-embed-text-v1.5`.
3. Go to the **Developer** tab, load the chat model (and the embedding model),
   and click **Start Server**. Default endpoint: `http://localhost:1234/v1`.
4. If the UI machine is separate, enable **Serve on Network** so the server
   binds beyond localhost.
5. Confirm the model identifier with `curl http://localhost:1234/v1/models` —
   the `id` field is what goes in `MODEL_NAME`.

| VRAM  | Model                     | Quality                 |
|-------|---------------------------|-------------------------|
| 8 GB  | `Llama-3.1-8B-Instruct`   | Good                    |
| 12 GB | `Qwen2.5-14B-Instruct`    | Excellent               |
| 24 GB | `Qwen2.5-32B-Instruct`    | Best local tool-calling |

Pick a model marked as tool-use capable in LM Studio.

---

## Step 2 — Windows Server: Start the Backend

```
backend/
  server.py      ← FastAPI harness, WebSocket, auth, routing
  tools.py       ← Tool definitions + workspace sandbox
  store.py       ← SQLite conversation persistence
  memory.py      ← ChromaDB vector memory
  setup.bat / start.bat / requirements.txt / .env.example
```

1. Run `setup.bat` (first time only). It creates the venv, installs deps,
   copies `.env`, and prints a generated `API_TOKEN`.
2. Edit `.env`:
   - `LMSTUDIO_URL` — LM Studio's endpoint (default `http://localhost:1234/v1`).
   - `MODEL_NAME` / `EMBED_MODEL` — exact ids from `GET /v1/models`.
   - `API_TOKEN` — paste the generated token (required unless localhost-only).
   - `ALLOWED_ORIGINS` — your UI machine's IP.
   - `FAST_MODEL` — optional; set to enable fast/main routing.
3. Run `start.bat`.

Verify: open `http://SERVER_IP:8000/health` — `lmstudio_reachable` should be `true`.

**Windows Firewall:** allow TCP port 8000 inbound.

---

## Step 3 — UI Machine: Start the Frontend

1. Install Node.js (https://nodejs.org).
2. Copy `frontend/.env.example` → `.env` and set:
   ```
   VITE_WS_URL=ws://SERVER_IP:8000
   VITE_API_URL=http://SERVER_IP:8000
   VITE_API_TOKEN=<same token as the backend>
   ```
3. `npm install` then `npm run dev`, and open `http://localhost:3000`.

---

## Tools (12)

| Tool | Notes |
|------|-------|
| `read_file` `write_file` `append_file` `list_directory` | Sandboxed to `WORKSPACE_ROOT` |
| `run_command` | Windows shell — **requires UI approval**, streams output |
| `run_python`  | Executes a Python 3 snippet — **requires UI approval** |
| `get_system_info` `get_current_datetime` | Server status / clock |
| `web_fetch` | Fetch a URL (async) |
| `remember` `recall` `memory_count` | ChromaDB long-term memory |

Add tools in `tools.py`. Stateless tools go in `get_stateless_tools()`.

---

## HTTP Endpoints

```
GET    /health                ← open; pings LM Studio
GET    /tools                 ← token required
GET    /sessions              ← token required
GET    /history/{session_id}  ← token required
DELETE /history/{session_id}  ← token required
WS     /ws/{session_id}?token=…
```

## WebSocket Protocol

```
Client → Server
  {"type":"chat","content":"…"}
  {"type":"cancel"}
  {"type":"confirm_response","id":"…","approved":true|false}
  {"type":"upload","filename":"…","data":"<base64>"}

Server → Client
  {"type":"status"|"token"|"done"|"error"|"system"|"cancelled", …}
  {"type":"tool_start","tool":"…","input":"…"}
  {"type":"tool_stream","tool":"…","line":"…"}
  {"type":"tool_end","tool":"…","result":"…"}
  {"type":"confirm","id":"…","action":"…","detail":"…"}
```

---

## Security Notes

- **Set `API_TOKEN`.** Without it, anyone who can reach port 8000 has agent
  access, including `run_command` shell execution.
- File tools cannot escape `WORKSPACE_ROOT`. Shell/Python tools are not
  path-limited but require explicit per-call approval in the UI.
- ChromaDB (`./chroma_db/`), SQLite (`./agent.db`), and uploads
  (`./workspace/`) all persist on the server — back them up.
- For internet-facing deployment, put this behind a reverse proxy with TLS.
