"""
server.py v3 - FastAPI agent harness with WebSocket streaming.

What's new in v3
  TIER 1 — security
    - Token auth on the WebSocket handshake and on data HTTP routes
    - File tools confined to a workspace sandbox (see tools.py)
    - Human-in-the-loop: run_command / run_python require UI approval
  TIER 2 — reliability
    - Cancellation: a running agent turn can be aborted mid-stream
    - /health verifies the LM Studio server is actually reachable
    - Structured logging to a rotating file + console
    - SQLite conversation persistence (see store.py)
  TIER 3 — capability
    - File upload over the WebSocket into the workspace
    - Automatic memory: conversations are summarised into long-term memory
    - Live tool-output streaming
    - Optional fast/main model routing per turn
  Plus a coding tool: run_python.
"""

import asyncio
import base64
import json
import logging
import os
import secrets
import uuid
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import (
    Depends,
    FastAPI,
    Header,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI

from memory import MemoryStore
from store import ConversationStore
from tools import WORKSPACE_ROOT, get_all_tools, safe_path

load_dotenv()

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _setup_logging() -> logging.Logger:
    log_dir = Path(os.getenv("LOG_DIR", "./logs"))
    log_dir.mkdir(exist_ok=True)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%H:%M:%S"
    )
    file_h = RotatingFileHandler(
        log_dir / "agent.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
    )
    file_h.setFormatter(fmt)
    con_h = logging.StreamHandler()
    con_h.setFormatter(fmt)
    logger = logging.getLogger("agent")
    logger.setLevel(logging.INFO)
    logger.handlers = [file_h, con_h]
    return logger


# Quiet LangChain's internal chatter
logging.getLogger("langchain").setLevel(logging.WARNING)
logging.getLogger("langchain_core").setLevel(logging.WARNING)
log = _setup_logging()

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

LMSTUDIO_URL  = os.getenv("LMSTUDIO_URL", "http://localhost:1234/v1")
MODEL_NAME    = os.getenv("MODEL_NAME", "qwen2.5-7b-instruct")
FAST_MODEL    = os.getenv("FAST_MODEL", "").strip()        # "" -> routing off
SYSTEM_PROMPT = os.getenv(
    "SYSTEM_PROMPT",
    "You are a capable AI assistant. Always respond in English. Use tools when "
    "they help you complete a task accurately. File tools operate inside a "
    "sandboxed workspace; shell and Python tools require user approval.",
)
MAX_HISTORY = int(os.getenv("MAX_HISTORY_TURNS", "20"))
MAX_ITER    = int(os.getenv("MAX_ITERATIONS", "10"))
# Note: context length is set in the LM Studio app when the model is loaded,
# not via the API — there is no num_ctx/keep_alive equivalent here.
ALLOWED_ORIG = os.getenv("ALLOWED_ORIGINS", "*").split(",")
API_TOKEN    = os.getenv("API_TOKEN", "").strip()
DB_PATH      = os.getenv("DB_PATH", "./agent.db")
AUTO_MEMORY  = os.getenv("AUTO_MEMORY", "true").lower() == "true"

store = ConversationStore(DB_PATH)

# Shared resources, built once in lifespan
_memory_store: MemoryStore | None = None
_llm_main: ChatOpenAI | None = None
_llm_fast: ChatOpenAI | None = None
_fast_enabled = False
_tool_specs: list[dict] = []

AGENT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    MessagesPlaceholder("chat_history"),
    ("human", "{input}"),
    MessagesPlaceholder("agent_scratchpad"),
])

# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

async def _noop_confirm(action: str, detail: str) -> bool:
    return True

async def _noop_emit(payload: dict) -> None:
    return None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _memory_store, _llm_main, _llm_fast, _fast_enabled, _tool_specs

    log.info("Boot: model '%s' via LM Studio at %s", MODEL_NAME, LMSTUDIO_URL)
    _memory_store = MemoryStore()

    # LM Studio exposes an OpenAI-compatible API. api_key is required by the
    # client but not checked by LM Studio — any non-empty string works.
    common = dict(base_url=LMSTUDIO_URL, api_key="lm-studio",
                  temperature=0.15, streaming=True)
    _llm_main = ChatOpenAI(model=MODEL_NAME, **common)

    if FAST_MODEL and FAST_MODEL != MODEL_NAME:
        _fast_enabled = True
        _llm_fast = ChatOpenAI(model=FAST_MODEL, **common)
        log.info("Fast-model routing enabled: '%s'", FAST_MODEL)
    else:
        _llm_fast = _llm_main
        log.info("Fast-model routing disabled (single model)")

    # Build the tool list once with no-op callbacks, just for /tools metadata
    specs = get_all_tools(_memory_store, _noop_confirm, _noop_emit)
    _tool_specs = [{"name": t.name, "description": t.description} for t in specs]

    log.info("Agent ready — %d tools. Workspace: %s", len(specs), WORKSPACE_ROOT)
    log.info("Auth: %s", "ENABLED" if API_TOKEN else "DISABLED — set API_TOKEN!")
    if not API_TOKEN:
        log.warning("No API_TOKEN set: anyone who can reach this port has agent access.")
    yield
    log.info("Shutdown.")


# ---------------------------------------------------------------------------
# Agent construction & routing
# ---------------------------------------------------------------------------

def _make_executor(llm: ChatOpenAI, tools: list) -> AgentExecutor:
    agent = create_tool_calling_agent(llm, tools, AGENT_PROMPT)
    return AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=False,
        max_iterations=MAX_ITER,
        handle_parsing_errors=True,
        return_intermediate_steps=True,
    )


def build_executors(tools: list) -> dict[str, AgentExecutor]:
    """Per-connection executors. 'fast' falls back to 'main' when routing is off."""
    main = _make_executor(_llm_main, tools)
    fast = _make_executor(_llm_fast, tools) if _fast_enabled else main
    return {"main": main, "fast": fast}


_HEAVY_KEYWORDS = (
    "code", "script", "python", "debug", "analyze", "refactor", "build",
    "powershell", "command", "fix", "error", "write", "implement", "compare",
)

def pick_model(text: str) -> str:
    """Route short, simple turns to the fast model; everything else to main."""
    if not _fast_enabled:
        return "main"
    low = text.lower()
    if len(text) > 280 or any(k in low for k in _HEAVY_KEYWORDS):
        return "main"
    return "fast"


async def summarize_to_memory(history: list) -> None:
    """Extract durable facts from a finished conversation into long-term memory."""
    if not AUTO_MEMORY or _memory_store is None or len(history) < 4:
        return
    convo = "\n".join(
        f"{'User' if isinstance(m, HumanMessage) else 'Agent'}: {m.content}"
        for m in history[-12:]
    )
    prompt = (
        "From the conversation below, extract durable facts about the user or "
        "their projects worth remembering long-term (preferences, decisions, "
        "ongoing work). One fact per line, max 6 lines, no numbering. "
        "If nothing is worth saving, reply with exactly NONE.\n\n" + convo
    )
    try:
        resp = await _llm_fast.ainvoke(prompt)
        text = (resp.content or "").strip()
        if not text or text.upper().startswith("NONE"):
            return
        saved = 0
        for line in text.splitlines():
            fact = line.strip(" -•*\t")
            if len(fact) > 8:
                _memory_store.add(fact, category="auto")
                saved += 1
        if saved:
            log.info("Auto-memory: saved %d fact(s)", saved)
    except Exception:
        log.exception("Auto-memory summarisation failed")


# ---------------------------------------------------------------------------
# Uploads
# ---------------------------------------------------------------------------

MAX_UPLOAD_BYTES = 5_000_000

def save_upload(filename: str, b64_data: str) -> str:
    if not filename or not b64_data:
        return "Upload failed: missing filename or data."
    dest = safe_path(os.path.basename(filename))
    if not dest:
        return f"Upload rejected: unsafe filename '{filename}'."
    try:
        data = base64.b64decode(b64_data)
    except Exception:
        return "Upload failed: data is not valid base64."
    if len(data) > MAX_UPLOAD_BYTES:
        return f"Upload rejected: exceeds {MAX_UPLOAD_BYTES // 1_000_000} MB limit."
    try:
        with open(dest, "wb") as f:
            f.write(data)
    except Exception as e:
        return f"Upload failed: {e}"
    name = os.path.basename(dest)
    return f"Uploaded '{name}' to the workspace ({len(data):,} bytes). Ask the agent to read it."


# ---------------------------------------------------------------------------
# App + auth
# ---------------------------------------------------------------------------

app = FastAPI(title="AI Agent API v3", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIG,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def require_token(x_api_token: str = Header(default="")):
    """HTTP dependency: rejects requests without the shared token (if one is set)."""
    if API_TOKEN and not secrets.compare_digest(x_api_token, API_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid or missing API token")


# ---------------------------------------------------------------------------
# HTTP Endpoints
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    """Open endpoint — also pings LM Studio so a green status is meaningful."""
    backend_ok = False
    try:
        async with httpx.AsyncClient(timeout=3) as c:
            backend_ok = (await c.get(f"{LMSTUDIO_URL}/models")).status_code == 200
    except Exception:
        backend_ok = False
    return {
        "status": "ok" if backend_ok else "degraded",
        "model": MODEL_NAME,
        "fast_model": FAST_MODEL or MODEL_NAME,
        "lmstudio_reachable": backend_ok,
        "auth_enabled": bool(API_TOKEN),
        "memory_docs": _memory_store.count() if _memory_store else 0,
        "saved_sessions": store.session_count(),
    }


@app.get("/tools", dependencies=[Depends(require_token)])
async def list_tools():
    return _tool_specs


@app.get("/sessions", dependencies=[Depends(require_token)])
async def get_sessions():
    return store.list_sessions()


@app.get("/history/{session_id}", dependencies=[Depends(require_token)])
async def get_history(session_id: str):
    return store.load_raw(session_id)


@app.delete("/history/{session_id}", dependencies=[Depends(require_token)])
async def clear_history(session_id: str):
    return {"cleared": store.clear(session_id)}


# ---------------------------------------------------------------------------
# WebSocket Chat
# ---------------------------------------------------------------------------
#
# Client -> Server
#   {"type":"chat","content":"..."}              start an agent turn
#   {"type":"cancel"}                            abort the running turn
#   {"type":"confirm_response","id":..,"approved":bool}
#   {"type":"upload","filename":"..","data":"<base64>"}
#
# Server -> Client
#   {"type":"status"|"token"|"done"|"error"|"system"|"cancelled", ...}
#   {"type":"tool_start","tool":..,"input":..}
#   {"type":"tool_stream","tool":..,"line":..}
#   {"type":"tool_end","tool":..,"result":..}
#   {"type":"confirm","id":..,"action":..,"detail":..}
# ---------------------------------------------------------------------------

@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    # --- auth on the handshake (token rides as a query param) ---
    if API_TOKEN and not secrets.compare_digest(
        websocket.query_params.get("token", ""), API_TOKEN
    ):
        await websocket.close(code=1008)  # policy violation
        log.warning("WS rejected (bad token): %s", session_id)
        return

    await websocket.accept()
    log.info("WS connected: %s", session_id)

    send_lock = asyncio.Lock()

    async def emit(payload: dict) -> None:
        async with send_lock:
            try:
                await websocket.send_text(json.dumps(payload))
            except Exception:
                pass

    pending: dict[str, asyncio.Future] = {}

    async def confirm(action: str, detail: str) -> bool:
        """Ask the UI to approve an action; block until it answers."""
        cid = uuid.uuid4().hex[:8]
        fut: asyncio.Future = asyncio.get_event_loop().create_future()
        pending[cid] = fut
        await emit({"type": "confirm", "id": cid, "action": action,
                    "detail": str(detail)[:600]})
        try:
            return await fut
        finally:
            pending.pop(cid, None)

    tools = get_all_tools(_memory_store, confirm, emit)
    executors = build_executors(tools)

    history = store.load_messages(session_id)
    if history:
        log.info("Loaded %d messages for %s", len(history), session_id)
    start_len = len(history)
    current: asyncio.Task | None = None

    async def run_agent(user_input: str) -> None:
        await emit({"type": "status", "content": "Thinking..."})
        which = pick_model(user_input)
        final_output = ""
        try:
            async for event in executors[which].astream_events(
                {"input": user_input, "chat_history": history}, version="v2"
            ):
                kind = event["event"]
                if kind == "on_tool_start":
                    await emit({
                        "type": "tool_start",
                        "tool": event["name"],
                        "input": str(event["data"].get("input", ""))[:300],
                    })
                elif kind == "on_tool_end":
                    await emit({
                        "type": "tool_end",
                        "tool": event["name"],
                        "result": str(event["data"].get("output", ""))[:600],
                    })
                elif kind == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    if getattr(chunk, "content", None):
                        await emit({"type": "token", "content": chunk.content})
                elif kind == "on_chain_end" and event["name"] == "AgentExecutor":
                    out = event["data"].get("output", {})
                    final_output = (
                        out.get("output", "") if isinstance(out, dict) else str(out)
                    )
        except asyncio.CancelledError:
            await emit({"type": "cancelled"})
            log.info("Turn cancelled: %s", session_id)
            raise
        except Exception as exc:
            log.exception("Agent run failed: %s", session_id)
            await emit({"type": "error", "content": str(exc)})
            return

        history.append(HumanMessage(content=user_input))
        history.append(AIMessage(content=final_output))
        if len(history) > MAX_HISTORY * 2:
            del history[: -(MAX_HISTORY * 2)]

        store.append_message(session_id, "human", user_input)
        store.append_message(session_id, "ai", final_output)
        await emit({"type": "done", "content": final_output, "model": which})

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            msg_type = msg.get("type") or ("chat" if msg.get("content") else "")

            if msg_type == "chat":
                content = (msg.get("content") or "").strip()
                if not content:
                    continue
                if current and not current.done():
                    await emit({"type": "error",
                                "content": "Agent is still working — cancel it first."})
                    continue
                current = asyncio.create_task(run_agent(content))

            elif msg_type == "cancel":
                if current and not current.done():
                    current.cancel()

            elif msg_type == "confirm_response":
                fut = pending.get(msg.get("id", ""))
                if fut and not fut.done():
                    fut.set_result(bool(msg.get("approved")))

            elif msg_type == "upload":
                result = save_upload(msg.get("filename", ""), msg.get("data", ""))
                await emit({"type": "system", "content": result})

    except WebSocketDisconnect:
        log.info("WS disconnected: %s", session_id)
    except Exception:
        log.exception("WS error: %s", session_id)
    finally:
        if current and not current.done():
            current.cancel()
        for fut in pending.values():
            if not fut.done():
                fut.cancel()
        if len(history) > start_len:
            await summarize_to_memory(history)
