@echo off
setlocal
echo ============================================
echo  AI Agent Backend
echo ============================================
echo.

if not exist "venv\Scripts\activate.bat" (
    echo [ERROR] Virtual environment not found. Run setup.bat first.
    pause & exit /b 1
)

call venv\Scripts\activate.bat

echo [INFO] Starting server on http://0.0.0.0:8000
echo [INFO] WebSocket endpoint: ws://0.0.0.0:8000/ws/{session_id}
echo [INFO] Press Ctrl+C to stop.
echo.

uvicorn server:app --host 0.0.0.0 --port 8000 --reload

pause
