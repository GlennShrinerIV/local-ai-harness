"""
store.py v3 - SQLite-backed conversation persistence.

Replaces v2's JSON-per-session files. Benefits:
  - Atomic appends instead of rewriting a whole file every turn
  - WAL mode + busy_timeout handle concurrent sessions safely
  - Indexed queries for the session list (no directory scan)

A fresh connection is opened per call. SQLite connections are cheap and
this keeps the store safe to use from many async tasks without sharing
a connection across threads.
"""

import sqlite3
from datetime import datetime

from langchain_core.messages import AIMessage, HumanMessage


class ConversationStore:
    def __init__(self, db_path: str = "./agent.db"):
        self.db_path = db_path
        self._init()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init(self) -> None:
        with self._conn() as c:
            c.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role       TEXT NOT NULL,          -- 'human' | 'ai'
                    content    TEXT NOT NULL,
                    ts         TEXT NOT NULL
                )
                """
            )
            c.execute(
                "CREATE INDEX IF NOT EXISTS idx_session ON messages(session_id, id)"
            )

    # -- writes -------------------------------------------------------------

    def append_message(self, session_id: str, role: str, content: str) -> None:
        """Append a single message. Atomic — no full-file rewrite."""
        with self._conn() as c:
            c.execute(
                "INSERT INTO messages (session_id, role, content, ts) VALUES (?,?,?,?)",
                (session_id, role, content, datetime.now().isoformat()),
            )

    def clear(self, session_id: str) -> bool:
        """Delete all messages for a session. Returns True if anything was removed."""
        with self._conn() as c:
            cur = c.execute("DELETE FROM messages WHERE session_id=?", (session_id,))
            return cur.rowcount > 0

    # -- reads --------------------------------------------------------------

    def load_messages(self, session_id: str) -> list:
        """Return history as LangChain message objects for the agent."""
        with self._conn() as c:
            rows = c.execute(
                "SELECT role, content FROM messages WHERE session_id=? ORDER BY id",
                (session_id,),
            ).fetchall()
        out = []
        for role, content in rows:
            out.append(
                HumanMessage(content=content)
                if role == "human"
                else AIMessage(content=content)
            )
        return out

    def load_raw(self, session_id: str) -> list[dict]:
        """Return history as plain dicts for the HTTP /history endpoint."""
        with self._conn() as c:
            rows = c.execute(
                "SELECT role, content, ts FROM messages WHERE session_id=? ORDER BY id",
                (session_id,),
            ).fetchall()
        return [{"role": r, "content": co, "ts": t} for r, co, t in rows]

    def list_sessions(self) -> list[dict]:
        """All sessions with message count, last-updated time, and a preview."""
        with self._conn() as c:
            rows = c.execute(
                """
                SELECT m.session_id,
                       COUNT(*)        AS n,
                       MAX(m.ts)       AS last,
                       (SELECT content FROM messages x
                         WHERE x.session_id = m.session_id
                         ORDER BY x.id DESC LIMIT 1) AS preview
                FROM messages m
                GROUP BY m.session_id
                ORDER BY last DESC
                """
            ).fetchall()
        return [
            {
                "session_id": s,
                "message_count": n,
                "last_updated": last,
                "preview": (preview or "")[:80],
            }
            for s, n, last, preview in rows
        ]

    def session_count(self) -> int:
        with self._conn() as c:
            return c.execute(
                "SELECT COUNT(DISTINCT session_id) FROM messages"
            ).fetchone()[0]
