"""
tools.py v3 - Agent tool definitions.

What's new in v3:
  - WORKSPACE_ROOT confinement: file tools are sandboxed to one directory
    via an allowlist (_safe_path), replacing v2's weaker denylist.
  - Human-in-the-loop: run_command and run_python ask the UI for approval
    before executing, via an injected async `confirm` callback.
  - Live output streaming: shell/python output is streamed line-by-line to
    the UI via an injected async `emit` callback.
  - run_python: a coding tool — executes a Python 3 snippet in the workspace.
"""

import asyncio
import os
import platform
import subprocess
import uuid
from datetime import datetime

import httpx
from langchain_core.tools import tool

# ---------------------------------------------------------------------------
# Workspace sandbox
# ---------------------------------------------------------------------------

WORKSPACE_ROOT = os.path.abspath(os.getenv("WORKSPACE_ROOT", "./workspace"))
os.makedirs(WORKSPACE_ROOT, exist_ok=True)


def safe_path(path: str) -> str | None:
    """
    Resolve `path` and guarantee it stays inside WORKSPACE_ROOT.
    Relative paths are taken relative to the workspace. Returns the absolute
    path, or None if the path escapes the sandbox (allowlist, not denylist).
    """
    candidate = path if os.path.isabs(path) else os.path.join(WORKSPACE_ROOT, path)
    resolved = os.path.abspath(candidate)
    try:
        if os.path.commonpath([resolved, WORKSPACE_ROOT]) != WORKSPACE_ROOT:
            return None
    except ValueError:
        return None  # e.g. different drive letters on Windows
    return resolved


# ---------------------------------------------------------------------------
# Shell command blocklist (a backstop — confirmation is the primary control)
# ---------------------------------------------------------------------------

BLOCKED_PATTERNS = [
    "rm -rf", "del /f", "del /q", "deltree",
    "format c", "format d", "format e",
    "shutdown", "restart-computer", "stop-computer",
    "reboot", "halt", "poweroff",
    "mkfs", "dd if=",
    "reg delete", "remove-item -recurse -force c:",
    ":(){ :|:& };:",
    "rd /s /q c:",
]


def _is_command_blocked(command: str) -> tuple[bool, str]:
    cmd = command.lower().strip()
    for pattern in BLOCKED_PATTERNS:
        if pattern.lower() in cmd:
            return True, pattern
    return False, ""


# ---------------------------------------------------------------------------
# File System Tools (workspace-confined)
# ---------------------------------------------------------------------------

@tool
def read_file(path: str) -> str:
    """
    Read and return the contents of a text file inside the agent workspace.
    Use for reading config files, source code, logs, or uploaded documents.
    Paths are relative to the workspace. Returns up to 15,000 characters.
    """
    resolved = safe_path(path)
    if not resolved:
        return f"[BLOCKED] Path escapes the workspace sandbox: {path}"
    try:
        with open(resolved, "r", encoding="utf-8", errors="replace") as f:
            content = f.read(15_000)
        lines = content.count("\n") + 1
        truncated = len(content) == 15_000
        header = f"[{lines} lines{', truncated at 15000 chars' if truncated else ''}]\n\n"
        return header + (content or "(empty file)")
    except FileNotFoundError:
        return f"File not found: {path}"
    except PermissionError:
        return f"Permission denied: {path}"
    except Exception as e:
        return f"Error reading file: {e}"


@tool
def write_file(path: str, content: str) -> str:
    """
    Write content to a file inside the agent workspace, creating any needed
    subdirectories. Use for saving reports, scripts, or config files.
    Paths are relative to the workspace and cannot escape it.
    """
    resolved = safe_path(path)
    if not resolved:
        return f"[BLOCKED] Path escapes the workspace sandbox: {path}"
    try:
        os.makedirs(os.path.dirname(resolved) or WORKSPACE_ROOT, exist_ok=True)
        with open(resolved, "w", encoding="utf-8") as f:
            f.write(content)
        size = os.path.getsize(resolved)
        return f"Wrote {len(content)} characters ({size} bytes) to {os.path.relpath(resolved, WORKSPACE_ROOT)}"
    except Exception as e:
        return f"Error writing file: {e}"


@tool
def append_file(path: str, content: str) -> str:
    """
    Append content to the end of a file inside the workspace without
    overwriting it. Use for adding log entries or extending an existing file.
    """
    resolved = safe_path(path)
    if not resolved:
        return f"[BLOCKED] Path escapes the workspace sandbox: {path}"
    try:
        os.makedirs(os.path.dirname(resolved) or WORKSPACE_ROOT, exist_ok=True)
        with open(resolved, "a", encoding="utf-8") as f:
            f.write(content)
        return f"Appended {len(content)} characters to {os.path.relpath(resolved, WORKSPACE_ROOT)}"
    except Exception as e:
        return f"Error appending to file: {e}"


@tool
def list_directory(path: str = ".") -> str:
    """
    List files and folders in a directory inside the workspace, with sizes.
    Use to explore what files exist before reading them. Paths are relative
    to the workspace root.
    """
    resolved = safe_path(path)
    if not resolved:
        return f"[BLOCKED] Path escapes the workspace sandbox: {path}"
    try:
        dirs, files = [], []
        for e in sorted(os.listdir(resolved)):
            full = os.path.join(resolved, e)
            if os.path.isdir(full):
                dirs.append(f"[DIR ]  {e}/")
            else:
                size = os.path.getsize(full)
                size_str = f"{size:,} B" if size < 1024 else f"{size // 1024:,} KB"
                files.append(f"[FILE]  {e}  ({size_str})")
        rel = os.path.relpath(resolved, WORKSPACE_ROOT)
        body = "\n".join(dirs + files) or "(empty directory)"
        return f"workspace/{rel}  —  {len(dirs)} folders, {len(files)} files\n\n{body}"
    except FileNotFoundError:
        return f"Directory not found: {path}"
    except Exception as e:
        return f"Error listing directory: {e}"


# ---------------------------------------------------------------------------
# System / DateTime Tools
# ---------------------------------------------------------------------------

@tool
def get_system_info() -> str:
    """
    Get current system information: OS, CPU usage, RAM usage, disk space,
    and uptime. Use when asked about server health or resource usage.
    """
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage(os.path.splitdrive(WORKSPACE_ROOT)[0] or "/")
        up = (datetime.now() - datetime.fromtimestamp(psutil.boot_time())).total_seconds()
        return (
            f"System: {platform.system()} {platform.release()} ({platform.machine()})\n"
            f"CPU Usage: {cpu}%\n"
            f"RAM: {ram.used // (1024**3)} GB / {ram.total // (1024**3)} GB ({ram.percent}%)\n"
            f"Disk: {disk.used // (1024**3)} GB / {disk.total // (1024**3)} GB ({disk.percent}%)\n"
            f"Uptime: {int(up // 3600)}h {int((up % 3600) // 60)}m\n"
            f"Python: {platform.python_version()}"
        )
    except ImportError:
        return (
            f"System: {platform.system()} {platform.release()}\n"
            f"Python: {platform.python_version()}\n"
            f"(Install psutil for CPU/RAM/disk stats: pip install psutil)"
        )
    except Exception as e:
        return f"Error getting system info: {e}"


@tool
def get_current_datetime() -> str:
    """
    Get the current date and time on the server. Use whenever the user asks
    the time/date, or when you need an accurate timestamp.
    """
    now = datetime.now()
    return (
        f"Current server date/time: {now.strftime('%A, %B %d, %Y at %I:%M %p')}\n"
        f"ISO format: {now.isoformat()}"
    )


# ---------------------------------------------------------------------------
# Web Tool
# ---------------------------------------------------------------------------

@tool
async def web_fetch(url: str) -> str:
    """
    Fetch the text content of a webpage or URL. Use for reading online
    documentation, checking APIs, or verifying information from the internet.
    Returns up to 8,000 characters.
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    try:
        async with httpx.AsyncClient(
            timeout=15, follow_redirects=True, headers=headers
        ) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            text = " ".join(resp.text.split())
            return f"[{url}]\n\n{text[:8_000]}"
    except httpx.HTTPStatusError as e:
        return f"HTTP {e.response.status_code} error fetching {url}"
    except httpx.TimeoutException:
        return f"Request timed out fetching {url}"
    except Exception as e:
        return f"Fetch error: {e}"


# ---------------------------------------------------------------------------
# Streaming subprocess helper
# ---------------------------------------------------------------------------

async def _run_streamed(command: str, emit, tool_name: str, timeout: int = 120) -> str:
    """
    Run `command` in the workspace, streaming each stdout line to the UI via
    `emit`. stderr is merged into stdout. Returns the full captured output.
    """
    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        cwd=WORKSPACE_ROOT,
    )
    lines: list[str] = []

    async def pump():
        assert proc.stdout is not None
        async for raw in proc.stdout:
            line = raw.decode("utf-8", "replace").rstrip()
            lines.append(line)
            await emit({"type": "tool_stream", "tool": tool_name, "line": line})

    try:
        await asyncio.wait_for(pump(), timeout=timeout)
        await proc.wait()
        code = proc.returncode
    except asyncio.TimeoutError:
        proc.kill()
        lines.append(f"[timed out after {timeout}s — process killed]")
        code = -1
    except asyncio.CancelledError:
        proc.kill()
        raise

    output = "\n".join(lines).strip()
    if not output:
        output = f"(no output — exit code {code})"
    return output[:6_000]


# ---------------------------------------------------------------------------
# Shell + Coding Tools (confirmation-gated, per-connection factory)
# ---------------------------------------------------------------------------

def make_exec_tools(confirm, emit):
    """
    Factory: builds the execution tools bound to one WebSocket connection.
      confirm(action, detail) -> awaitable[bool]   — asks the user to approve
      emit(payload)           -> awaitable[None]   — streams output to the UI
    """

    @tool
    async def run_command(command: str) -> str:
        """
        Run a Windows shell command (PowerShell or cmd) and return its output.
        Use for system administration: checking services, querying system
        state, running scripts. The user must approve each command before it
        runs. Output streams live. Timeout: 120 seconds.
        """
        blocked, pattern = _is_command_blocked(command)
        if blocked:
            return f"[BLOCKED] Command contains restricted operation '{pattern}'."
        approved = await confirm("run_command", command)
        if not approved:
            return "[DENIED] The user declined to run this command."
        try:
            return await _run_streamed(command, emit, "run_command")
        except Exception as e:
            return f"Execution error: {e}"

    @tool
    async def run_python(code: str) -> str:
        """
        Execute a Python 3 script and return its output. Use this to perform
        calculations, transform data, test logic, or solve coding tasks that
        are easier to compute than reason about. The script runs in the agent
        workspace; the user must approve it first. Output streams live.
        Print results you want to see — only stdout/stderr is returned.
        """
        approved = await confirm("run_python", code)
        if not approved:
            return "[DENIED] The user declined to run this code."
        script = safe_path(f"_snippet_{uuid.uuid4().hex[:8]}.py")
        if not script:
            return "[ERROR] Could not create a workspace script path."
        try:
            with open(script, "w", encoding="utf-8") as f:
                f.write(code)
            return await _run_streamed(
                f'python -X utf8 "{script}"', emit, "run_python"
            )
        except Exception as e:
            return f"Execution error: {e}"
        finally:
            try:
                os.remove(script)
            except OSError:
                pass

    return [run_command, run_python]


# ---------------------------------------------------------------------------
# Memory Tools (per-MemoryStore factory)
# ---------------------------------------------------------------------------

def make_memory_tools(memory_store):
    """Factory: injects the MemoryStore instance into tool closures."""

    @tool
    def remember(text: str) -> str:
        """
        Save important information to long-term memory for future retrieval.
        Use when the user shares facts, preferences, project details, or
        decisions they'll want recalled in later conversations.
        """
        memory_store.add(text, category="explicit")
        return f"Saved to memory: {text[:120]}"

    @tool
    def recall(query: str) -> str:
        """
        Search long-term memory for information relevant to a query.
        Use when the user references past conversations or asks what you
        know about them. Searches by meaning, not exact keywords.
        """
        results = memory_store.search(query, k=5)
        if not results:
            return "Nothing relevant found in long-term memory for that query."
        body = "\n---\n".join(f"[Memory {i+1}]: {r}" for i, r in enumerate(results))
        return f"Found {len(results)} relevant memories:\n\n{body}"

    @tool
    def memory_count() -> str:
        """Check how many items are stored in long-term memory."""
        n = memory_store.count()
        return f"Long-term memory contains {n} stored item{'s' if n != 1 else ''}."

    return [remember, recall, memory_count]


# ---------------------------------------------------------------------------
# Tool Registry
# ---------------------------------------------------------------------------

def get_stateless_tools():
    """Tools with no per-connection or per-store dependency."""
    return [
        read_file,
        write_file,
        append_file,
        list_directory,
        get_system_info,
        get_current_datetime,
        web_fetch,
    ]


def get_all_tools(memory_store, confirm, emit):
    """
    The full tool set for one WebSocket connection.
      memory_store : shared MemoryStore
      confirm/emit : per-connection async callbacks (see make_exec_tools)
    """
    return (
        get_stateless_tools()
        + make_exec_tools(confirm, emit)
        + make_memory_tools(memory_store)
    )
