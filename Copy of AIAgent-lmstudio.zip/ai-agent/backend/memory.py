"""
memory.py - ChromaDB-backed vector memory store.

Embeddings are served by LM Studio's OpenAI-compatible /v1/embeddings
endpoint. Load an embedding model in LM Studio (e.g.
text-embedding-nomic-embed-text-v1.5) for this to work.

Features:
  - Timestamps stored with every memory entry
  - Category tagging support (agent can tag memories as 'preference', 'fact', 'task', etc.)
  - delete() method so agent can remove outdated memories
  - list_recent() so agent can browse what it remembers
  - Better search: returns metadata alongside content
"""

import os
import uuid
from datetime import datetime
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings


class MemoryStore:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings(
            model=os.getenv("EMBED_MODEL", "text-embedding-nomic-embed-text-v1.5"),
            base_url=os.getenv("LMSTUDIO_URL", "http://localhost:1234/v1"),
            api_key="lm-studio",
            # LM Studio is not OpenAI — skip tiktoken-based pre-chunking,
            # which otherwise misbehaves against a local server.
            check_embedding_ctx_length=False,
        )
        self.vectorstore = Chroma(
            collection_name="agent_memory",
            embedding_function=self.embeddings,
            persist_directory="./chroma_db",
        )
        count = self.vectorstore._collection.count()
        print(f"[Memory] Loaded ChromaDB — {count} memories stored.")

    def add(self, text: str, category: str = "general", metadata: dict | None = None) -> str:
        """Store a memory with timestamp and optional category tag."""
        mem_id = str(uuid.uuid4())[:8]
        meta = {
            "id": mem_id,
            "timestamp": datetime.now().isoformat(),
            "category": category,
            **(metadata or {}),
        }
        self.vectorstore.add_texts([text], metadatas=[meta], ids=[mem_id])
        return mem_id

    def search(self, query: str, k: int = 5) -> list[str]:
        """Search by semantic similarity. Returns text content only."""
        try:
            docs = self.vectorstore.similarity_search(query, k=k)
            return [d.page_content for d in docs]
        except Exception as e:
            print(f"[Memory] Search error: {e}")
            return []

    def search_with_metadata(self, query: str, k: int = 5) -> list[dict]:
        """Search and return content + metadata (timestamp, category, etc)."""
        try:
            docs = self.vectorstore.similarity_search(query, k=k)
            return [
                {
                    "content": d.page_content,
                    "timestamp": d.metadata.get("timestamp", "unknown"),
                    "category": d.metadata.get("category", "general"),
                    "id": d.metadata.get("id", ""),
                }
                for d in docs
            ]
        except Exception as e:
            print(f"[Memory] Search error: {e}")
            return []

    def list_recent(self, limit: int = 10) -> list[dict]:
        """Return the most recently added memories."""
        try:
            result = self.vectorstore._collection.get(
                limit=limit,
                include=["documents", "metadatas"],
            )
            items = []
            for doc, meta in zip(result["documents"], result["metadatas"]):
                items.append({
                    "content": doc,
                    "timestamp": meta.get("timestamp", "unknown"),
                    "category": meta.get("category", "general"),
                    "id": meta.get("id", ""),
                })
            # Sort by timestamp descending
            items.sort(key=lambda x: x["timestamp"], reverse=True)
            return items[:limit]
        except Exception as e:
            print(f"[Memory] list_recent error: {e}")
            return []

    def delete(self, memory_id: str) -> bool:
        """Delete a specific memory by its ID."""
        try:
            self.vectorstore._collection.delete(ids=[memory_id])
            return True
        except Exception as e:
            print(f"[Memory] Delete error: {e}")
            return False

    def count(self) -> int:
        return self.vectorstore._collection.count()
