@echo off
setlocal
echo ============================================
echo  AI Agent Backend - First-Time Setup
echo ============================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install from https://python.org
    pause & exit /b 1
)

:: Create virtualenv
if not exist "venv" (
    echo [1/3] Creating virtual environment...
    python -m venv venv
)

:: Activate and install
echo [2/3] Installing dependencies...
call venv\Scripts\activate.bat
pip install --upgrade pip -q
pip install -r requirements.txt

:: Copy .env if missing
if not exist ".env" (
    echo [3/3] Creating .env from template...
    copy .env.example .env
    echo.
    echo  ** Edit .env before starting the server: **
    echo     - Set ALLOWED_ORIGINS to your UI machine's IP
    echo     - Set API_TOKEN to a secret (generate one below)
    echo.
    echo  Generate an API token:
    python -c "import secrets; print('   API_TOKEN=' + secrets.token_urlsafe(24))"
) else (
    echo [3/3] .env already exists, skipping.
)

echo.
echo Setup complete! Run start.bat to launch the server.
pause
