import { useState, useEffect, useRef, useCallback } from 'react'

const WS_BASE  = import.meta.env.VITE_WS_URL   || 'ws://localhost:8000'
const API_BASE = import.meta.env.VITE_API_URL  || 'http://localhost:8000'
const TOKEN    = import.meta.env.VITE_API_TOKEN || ''

const authHeaders = TOKEN ? { 'X-API-Token': TOKEN } : {}

function genSessionId() {
  return 'sess_' + Math.random().toString(36).slice(2, 10)
}

// ─── Styles ───────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500&family=IBM+Plex+Sans:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:        #0a0c0f;
    --surface:   #111318;
    --surface2:  #181c24;
    --border:    #1e2330;
    --border2:   #2a3040;
    --text:      #c8d0dc;
    --muted:     #4a5568;
    --accent:    #4ade80;
    --accent2:   #22c55e;
    --tool:      #60a5fa;
    --tool-bg:   rgba(96,165,250,0.07);
    --tool-result-bg: rgba(96,165,250,0.04);
    --user-bg:   rgba(74,222,128,0.06);
    --error:     #f87171;
    --warn:      #fbbf24;
    --mono:      'IBM Plex Mono', monospace;
    --sans:      'IBM Plex Sans', sans-serif;
  }

  html, body, #root { height: 100%; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--sans);
    font-size: 14px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }

  /* ── Layout ── */
  .app {
    display: flex;
    height: 100vh;
    overflow: hidden;
  }

  /* ── Sidebar ── */
  .sidebar {
    width: 220px;
    flex-shrink: 0;
    background: var(--surface);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    overflow: hidden;
    transition: width 0.2s ease;
  }

  .sidebar.collapsed { width: 0; overflow: hidden; }

  .sidebar-header {
    padding: 14px 16px;
    border-bottom: 1px solid var(--border);
    font-family: var(--mono);
    font-size: 10px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--muted);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .new-session-btn {
    background: rgba(74,222,128,0.1);
    border: 1px solid rgba(74,222,128,0.2);
    color: var(--accent);
    font-family: var(--mono);
    font-size: 10px;
    border-radius: 3px;
    padding: 2px 7px;
    cursor: pointer;
    transition: background 0.15s;
  }
  .new-session-btn:hover { background: rgba(74,222,128,0.2); }

  .session-list {
    flex: 1;
    overflow-y: auto;
    padding: 8px;
  }
  .session-list::-webkit-scrollbar { width: 3px; }
  .session-list::-webkit-scrollbar-thumb { background: var(--border2); }

  .session-item {
    padding: 9px 10px;
    border-radius: 5px;
    cursor: pointer;
    margin-bottom: 3px;
    transition: background 0.1s;
    border: 1px solid transparent;
  }
  .session-item:hover { background: var(--surface2); }
  .session-item.active {
    background: var(--surface2);
    border-color: var(--border2);
  }

  .session-id {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--accent);
    margin-bottom: 2px;
  }

  .session-preview {
    font-size: 11px;
    color: var(--muted);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .session-meta {
    font-family: var(--mono);
    font-size: 9px;
    color: var(--border2);
    margin-top: 3px;
  }

  /* ── Main Shell ── */
  .shell {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    min-width: 0;
  }

  /* ── Header ── */
  .header {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 20px;
    border-bottom: 1px solid var(--border);
    background: var(--surface);
    flex-shrink: 0;
  }

  .sidebar-toggle {
    background: none;
    border: none;
    color: var(--muted);
    cursor: pointer;
    font-size: 16px;
    padding: 2px 6px;
    border-radius: 3px;
    transition: color 0.15s;
  }
  .sidebar-toggle:hover { color: var(--text); }

  .header-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: var(--accent);
    box-shadow: 0 0 6px var(--accent2);
    flex-shrink: 0;
  }
  .header-dot.offline { background: var(--muted); box-shadow: none; }

  .header-title {
    font-family: var(--mono);
    font-size: 13px;
    font-weight: 500;
    color: var(--text);
    letter-spacing: 0.04em;
  }

  .header-model {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    margin-left: auto;
  }

  .tools-badge {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--tool);
    background: var(--tool-bg);
    border: 1px solid rgba(96,165,250,0.2);
    border-radius: 4px;
    padding: 2px 7px;
    cursor: pointer;
    transition: background 0.15s;
  }
  .tools-badge:hover { background: rgba(96,165,250,0.14); }

  /* ── Tool Drawer ── */
  .tool-drawer {
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.25s ease;
  }
  .tool-drawer.open { max-height: 200px; }
  .tool-list {
    padding: 10px 20px;
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .tool-chip {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--tool);
    background: var(--tool-bg);
    border: 1px solid rgba(96,165,250,0.18);
    border-radius: 4px;
    padding: 3px 9px;
  }

  /* ── Messages ── */
  .messages {
    flex: 1;
    overflow-y: auto;
    padding: 24px 20px;
    display: flex;
    flex-direction: column;
    gap: 18px;
    scroll-behavior: smooth;
  }
  .messages::-webkit-scrollbar { width: 4px; }
  .messages::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 2px; }

  /* ── Welcome ── */
  .welcome {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    gap: 12px;
    padding: 40px;
    text-align: center;
  }
  .welcome-glyph { font-family: var(--mono); font-size: 32px; color: var(--accent); opacity: 0.7; }
  .welcome h2 { font-family: var(--mono); font-size: 15px; font-weight: 500; letter-spacing: 0.05em; }
  .welcome p { font-size: 13px; color: var(--muted); max-width: 380px; }

  /* ── Message Bubbles ── */
  .msg-row { display: flex; flex-direction: column; gap: 4px; }
  .msg-row.user { align-items: flex-end; }
  .msg-row.assistant { align-items: flex-start; }

  .msg-label {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding: 0 4px;
  }

  .msg-bubble {
    max-width: 80%;
    padding: 12px 16px;
    border-radius: 6px;
    font-size: 13.5px;
    line-height: 1.65;
    white-space: pre-wrap;
    word-break: break-word;
  }
  .msg-bubble.user {
    background: var(--user-bg);
    border: 1px solid rgba(74,222,128,0.18);
  }
  .msg-bubble.assistant {
    background: var(--surface);
    border: 1px solid var(--border);
  }

  /* ── Tool Events ── */
  .tool-block {
    max-width: 80%;
    border: 1px solid rgba(96,165,250,0.15);
    border-radius: 5px;
    overflow: hidden;
    font-family: var(--mono);
    font-size: 11px;
  }

  .tool-header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: var(--tool-bg);
    color: var(--tool);
    cursor: pointer;
    user-select: none;
  }
  .tool-header .te-name { font-weight: 500; }
  .tool-header .te-input { color: var(--muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
  .tool-header .te-toggle { color: var(--muted); margin-left: auto; flex-shrink: 0; }

  .tool-result {
    background: var(--tool-result-bg);
    border-top: 1px solid rgba(96,165,250,0.1);
    padding: 8px 12px;
    color: #9399b2;
    white-space: pre-wrap;
    word-break: break-all;
    max-height: 220px;
    overflow-y: auto;
    font-size: 11px;
  }

  .tool-block.done .tool-header { opacity: 0.7; }

  /* ── Confirmation prompt ── */
  .confirm-block {
    max-width: 80%;
    border: 1px solid rgba(251,191,36,0.35);
    background: rgba(251,191,36,0.06);
    border-radius: 6px;
    overflow: hidden;
  }
  .confirm-head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    font-family: var(--mono);
    font-size: 11px;
    color: var(--warn);
    border-bottom: 1px solid rgba(251,191,36,0.2);
  }
  .confirm-detail {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--text);
    background: var(--bg);
    padding: 10px 14px;
    white-space: pre-wrap;
    word-break: break-all;
    max-height: 180px;
    overflow-y: auto;
  }
  .confirm-actions {
    display: flex;
    gap: 8px;
    padding: 10px 14px;
  }
  .confirm-actions button {
    font-family: var(--mono);
    font-size: 11px;
    font-weight: 500;
    border-radius: 4px;
    padding: 6px 16px;
    cursor: pointer;
    border: 1px solid transparent;
  }
  .confirm-actions .approve {
    background: var(--accent);
    color: #0a0c0f;
  }
  .confirm-actions .approve:hover { background: var(--accent2); }
  .confirm-actions .deny {
    background: transparent;
    border-color: rgba(248,113,113,0.4);
    color: var(--error);
  }
  .confirm-actions .deny:hover { background: rgba(248,113,113,0.1); }
  .confirm-resolved {
    font-family: var(--mono);
    font-size: 11px;
    padding: 8px 14px;
  }
  .confirm-resolved.yes { color: var(--accent); }
  .confirm-resolved.no  { color: var(--error); }

  /* ── Status / System / Error ── */
  .status-row {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    padding-left: 4px;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .status-row::before { content: '▸'; color: var(--accent); opacity: 0.6; }

  .system-msg {
    font-family: var(--mono);
    font-size: 11px;
    color: var(--tool);
    background: var(--tool-bg);
    border: 1px solid rgba(96,165,250,0.18);
    border-radius: 4px;
    padding: 7px 14px;
    max-width: 80%;
  }

  .error-msg {
    font-family: var(--mono);
    font-size: 12px;
    color: var(--error);
    background: rgba(248,113,113,0.07);
    border: 1px solid rgba(248,113,113,0.2);
    border-radius: 4px;
    padding: 8px 14px;
    max-width: 80%;
  }

  /* ── Cursor ── */
  .cursor {
    display: inline-block;
    width: 7px; height: 14px;
    background: var(--accent);
    border-radius: 1px;
    margin-left: 2px;
    vertical-align: text-bottom;
    animation: blink 1s step-end infinite;
  }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }

  /* ── Input ── */
  .input-bar {
    border-top: 1px solid var(--border);
    background: var(--surface);
    padding: 12px 16px;
    display: flex;
    align-items: flex-end;
    gap: 10px;
    flex-shrink: 0;
  }

  .input-prefix {
    font-family: var(--mono);
    font-size: 13px;
    color: var(--accent);
    padding-bottom: 11px;
    flex-shrink: 0;
    user-select: none;
  }

  .icon-btn {
    background: var(--bg);
    border: 1px solid var(--border2);
    border-radius: 5px;
    color: var(--muted);
    font-size: 15px;
    height: 44px;
    width: 42px;
    cursor: pointer;
    flex-shrink: 0;
    align-self: flex-end;
    transition: color 0.15s, border-color 0.15s;
  }
  .icon-btn:hover:not(:disabled) { color: var(--accent); border-color: rgba(74,222,128,0.35); }
  .icon-btn:disabled { opacity: 0.35; cursor: default; }

  textarea {
    flex: 1;
    background: var(--bg);
    border: 1px solid var(--border2);
    border-radius: 5px;
    color: var(--text);
    font-family: var(--sans);
    font-size: 13.5px;
    line-height: 1.55;
    padding: 10px 13px;
    resize: none;
    min-height: 44px;
    max-height: 180px;
    outline: none;
    transition: border-color 0.15s;
  }
  textarea:focus { border-color: rgba(74,222,128,0.35); }
  textarea::placeholder { color: var(--muted); }

  .send-btn {
    background: var(--accent);
    border: none;
    border-radius: 5px;
    color: #0a0c0f;
    font-family: var(--mono);
    font-size: 13px;
    font-weight: 500;
    padding: 10px 16px;
    cursor: pointer;
    flex-shrink: 0;
    transition: background 0.15s, transform 0.1s;
    height: 44px;
    align-self: flex-end;
  }
  .send-btn:hover:not(:disabled) { background: var(--accent2); transform: translateY(-1px); }
  .send-btn:disabled { opacity: 0.35; cursor: default; transform: none; }
  .send-btn.stop {
    background: transparent;
    border: 1px solid rgba(248,113,113,0.5);
    color: var(--error);
  }
  .send-btn.stop:hover:not(:disabled) { background: rgba(248,113,113,0.12); }

  .footer {
    padding: 5px 20px;
    border-top: 1px solid var(--border);
    background: var(--bg);
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    display: flex;
    gap: 16px;
    flex-shrink: 0;
  }

  @media (max-width: 600px) {
    .sidebar { display: none; }
    .msg-bubble, .tool-block, .confirm-block { max-width: 95%; }
  }
`

// ─── ToolBlock ─────────────────────────────────────────────────────────────
function ToolBlock({ tool, input, stream, result, done }) {
  const [expanded, setExpanded] = useState(false)
  const body = stream.length ? stream.join('\n') : (result || '')
  const show = expanded || (!done && stream.length > 0)

  return (
    <div className={`tool-block ${done ? 'done' : ''}`}>
      <div className="tool-header" onClick={() => body && setExpanded(e => !e)}>
        <span>⚙</span>
        <span className="te-name">{tool}</span>
        {input && <span className="te-input">{input}</span>}
        {body && <span className="te-toggle">{show ? '▲' : '▼'}</span>}
        {!done && <span style={{ color: 'var(--warn)', marginLeft: 'auto' }}>running…</span>}
      </div>
      {show && body && <div className="tool-result">{body}</div>}
    </div>
  )
}

// ─── ConfirmBlock ──────────────────────────────────────────────────────────
function ConfirmBlock({ action, detail, answered, onAnswer }) {
  return (
    <div className="confirm-block">
      <div className="confirm-head">
        <span>⚠</span>
        <span>Approval required — <b>{action}</b></span>
      </div>
      <div className="confirm-detail">{detail}</div>
      {answered === null ? (
        <div className="confirm-actions">
          <button className="approve" onClick={() => onAnswer(true)}>Approve</button>
          <button className="deny" onClick={() => onAnswer(false)}>Deny</button>
        </div>
      ) : (
        <div className={`confirm-resolved ${answered ? 'yes' : 'no'}`}>
          {answered ? '✓ Approved' : '✕ Denied'}
        </div>
      )}
    </div>
  )
}

// ─── App ───────────────────────────────────────────────────────────────────
export default function App() {
  const [sessionId, setSessionId]     = useState(genSessionId)
  const [messages, setMessages]       = useState([])
  const [input, setInput]             = useState('')
  const [connected, setConnected]     = useState(false)
  const [streaming, setStreaming]     = useState(false)
  const [streamBuf, setStreamBuf]     = useState('')
  const [tools, setTools]             = useState([])
  const [toolsOpen, setToolsOpen]     = useState(false)
  const [sessions, setSessions]       = useState([])
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [lastModel, setLastModel]     = useState('')

  const wsRef   = useRef(null)
  const endRef  = useRef(null)
  const fileRef = useRef(null)

  // Fetch tools
  useEffect(() => {
    fetch(`${API_BASE}/tools`, { headers: authHeaders })
      .then(r => r.json()).then(setTools).catch(() => {})
  }, [])

  // Fetch sessions
  const refreshSessions = useCallback(() => {
    fetch(`${API_BASE}/sessions`, { headers: authHeaders })
      .then(r => r.json()).then(setSessions).catch(() => {})
  }, [])
  useEffect(() => { refreshSessions() }, [refreshSessions])

  // Scroll
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streamBuf])

  // WebSocket
  const connect = useCallback(() => {
    const url = `${WS_BASE}/ws/${sessionId}` +
      (TOKEN ? `?token=${encodeURIComponent(TOKEN)}` : '')
    const ws = new WebSocket(url)

    ws.onopen  = () => setConnected(true)
    ws.onclose = () => {
      setConnected(false)
      setStreaming(false)
      setTimeout(connect, 3000)
    }
    ws.onerror = () => ws.close()

    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data)
      const dropStatus = (prev) => prev.filter(m => m.type !== 'status')

      if (msg.type === 'status') {
        setMessages(prev => [...prev, { type: 'status', content: msg.content }])

      } else if (msg.type === 'tool_start') {
        setMessages(prev => [...prev, {
          type: 'tool', id: `${Date.now()}-${Math.random()}`,
          tool: msg.tool, input: msg.input, stream: [], result: null, done: false,
        }])

      } else if (msg.type === 'tool_stream') {
        setMessages(prev => prev.map(m =>
          m.type === 'tool' && m.tool === msg.tool && !m.done
            ? { ...m, stream: [...m.stream, msg.line] }
            : m
        ))

      } else if (msg.type === 'tool_end') {
        setMessages(prev => prev.map(m =>
          m.type === 'tool' && m.tool === msg.tool && !m.done
            ? { ...m, done: true, result: msg.result || null }
            : m
        ))

      } else if (msg.type === 'confirm') {
        setMessages(prev => [...prev, {
          type: 'confirm', id: msg.id, action: msg.action,
          detail: msg.detail, answered: null,
        }])

      } else if (msg.type === 'token') {
        setStreaming(true)
        setStreamBuf(prev => prev + msg.content)

      } else if (msg.type === 'done') {
        setMessages(prev => [...dropStatus(prev), { type: 'assistant', content: msg.content }])
        setStreamBuf('')
        setStreaming(false)
        if (msg.model) setLastModel(msg.model)
        refreshSessions()

      } else if (msg.type === 'cancelled') {
        setMessages(prev => [...dropStatus(prev), { type: 'system', content: 'Turn cancelled.' }])
        setStreamBuf('')
        setStreaming(false)

      } else if (msg.type === 'system') {
        setMessages(prev => [...prev, { type: 'system', content: msg.content }])

      } else if (msg.type === 'error') {
        setMessages(prev => [...dropStatus(prev), { type: 'error', content: msg.content }])
        setStreamBuf('')
        setStreaming(false)
      }
    }

    wsRef.current = ws
  }, [sessionId, refreshSessions])

  // Reconnect on session change
  useEffect(() => {
    if (wsRef.current) wsRef.current.close()
    const t = setTimeout(connect, 100)
    return () => { clearTimeout(t); wsRef.current?.close() }
  }, [connect])

  // Actions
  const send = useCallback(() => {
    const text = input.trim()
    if (!text || !connected || streaming) return
    setMessages(prev => [...prev, { type: 'user', content: text }])
    setInput('')
    setStreamBuf('')
    wsRef.current.send(JSON.stringify({ type: 'chat', content: text }))
  }, [input, connected, streaming])

  const cancelTurn = useCallback(() => {
    wsRef.current?.send(JSON.stringify({ type: 'cancel' }))
  }, [])

  const answerConfirm = useCallback((id, approved) => {
    wsRef.current?.send(JSON.stringify({ type: 'confirm_response', id, approved }))
    setMessages(prev => prev.map(m =>
      m.type === 'confirm' && m.id === id ? { ...m, answered: approved } : m
    ))
  }, [])

  const onPickFile = (e) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !connected) return
    const reader = new FileReader()
    reader.onload = () => {
      const data = String(reader.result).split(',')[1]
      wsRef.current?.send(JSON.stringify({ type: 'upload', filename: file.name, data }))
    }
    reader.readAsDataURL(file)
  }

  const switchSession = useCallback((id) => {
    setSessionId(id)
    setMessages([])
    setStreamBuf('')
    fetch(`${API_BASE}/history/${id}`, { headers: authHeaders })
      .then(r => r.json())
      .then(data => setMessages(data.map(m => ({
        type: m.role === 'human' ? 'user' : 'assistant', content: m.content,
      }))))
      .catch(() => {})
  }, [])

  const newSession = () => {
    setSessionId(genSessionId())
    setMessages([])
    setStreamBuf('')
  }

  const onKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
  }
  const onInput = (e) => {
    setInput(e.target.value)
    e.target.style.height = 'auto'
    e.target.style.height = Math.min(e.target.scrollHeight, 180) + 'px'
  }

  const hasMessages = messages.length > 0 || streamBuf

  return (
    <>
      <style>{css}</style>
      <div className="app">

        {/* Sidebar */}
        <div className={`sidebar ${sidebarOpen ? '' : 'collapsed'}`}>
          <div className="sidebar-header">
            Sessions
            <button className="new-session-btn" onClick={newSession}>+ New</button>
          </div>
          <div className="session-list">
            {sessions.map(s => (
              <div
                key={s.session_id}
                className={`session-item ${s.session_id === sessionId ? 'active' : ''}`}
                onClick={() => switchSession(s.session_id)}
              >
                <div className="session-id">{s.session_id}</div>
                <div className="session-preview">{s.preview || '(empty)'}</div>
                <div className="session-meta">{s.message_count} msgs</div>
              </div>
            ))}
            {sessions.length === 0 && (
              <div style={{ padding: '12px 8px', fontSize: '11px', color: 'var(--muted)' }}>
                No saved sessions yet
              </div>
            )}
          </div>
        </div>

        {/* Main */}
        <div className="shell">

          {/* Header */}
          <div className="header">
            <button className="sidebar-toggle" onClick={() => setSidebarOpen(o => !o)}>☰</button>
            <div className={`header-dot ${connected ? '' : 'offline'}`} />
            <span className="header-title">AI AGENT TERMINAL</span>
            {tools.length > 0 && (
              <span className="tools-badge" onClick={() => setToolsOpen(o => !o)}>
                {tools.length} tools {toolsOpen ? '▲' : '▼'}
              </span>
            )}
            <span className="header-model">{sessionId}</span>
          </div>

          {/* Tool Drawer */}
          <div className={`tool-drawer ${toolsOpen ? 'open' : ''}`}>
            <div className="tool-list">
              {tools.map(t => (
                <span className="tool-chip" key={t.name} title={t.description}>{t.name}</span>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div className="messages">
            {!hasMessages && (
              <div className="welcome">
                <div className="welcome-glyph">⬡</div>
                <h2>AGENT READY</h2>
                <p>Connected to your local model. Send a message to begin.</p>
              </div>
            )}

            {messages.map((m, i) => {
              if (m.type === 'user') return (
                <div className="msg-row user" key={i}>
                  <div className="msg-label">you</div>
                  <div className="msg-bubble user">{m.content}</div>
                </div>
              )
              if (m.type === 'assistant') return (
                <div className="msg-row assistant" key={i}>
                  <div className="msg-label">agent</div>
                  <div className="msg-bubble assistant">{m.content}</div>
                </div>
              )
              if (m.type === 'status') return (
                <div className="status-row" key={i}>{m.content}</div>
              )
              if (m.type === 'tool') return <ToolBlock key={i} {...m} />
              if (m.type === 'confirm') return (
                <ConfirmBlock key={i} {...m} onAnswer={(a) => answerConfirm(m.id, a)} />
              )
              if (m.type === 'system') return (
                <div className="system-msg" key={i}>{m.content}</div>
              )
              if (m.type === 'error') return (
                <div className="error-msg" key={i}>⚠ {m.content}</div>
              )
              return null
            })}

            {streamBuf && (
              <div className="msg-row assistant">
                <div className="msg-label">agent</div>
                <div className="msg-bubble assistant">
                  {streamBuf}<span className="cursor" />
                </div>
              </div>
            )}

            <div ref={endRef} />
          </div>

          {/* Input */}
          <div className="input-bar">
            <span className="input-prefix">▸</span>
            <input ref={fileRef} type="file" hidden onChange={onPickFile} />
            <button
              className="icon-btn"
              title="Upload a file to the workspace"
              onClick={() => fileRef.current?.click()}
              disabled={!connected}
            >📎</button>
            <textarea
              value={input}
              onChange={onInput}
              onKeyDown={onKeyDown}
              placeholder={connected ? 'Send a message… (Enter to send, Shift+Enter for newline)' : 'Connecting…'}
              disabled={!connected || streaming}
              rows={1}
            />
            {streaming ? (
              <button className="send-btn stop" onClick={cancelTurn}>STOP</button>
            ) : (
              <button
                className="send-btn"
                onClick={send}
                disabled={!connected || !input.trim()}
              >RUN</button>
            )}
          </div>

          <div className="footer">
            <span>{connected ? '● connected' : '○ reconnecting'}</span>
            <span>{sessionId}</span>
            {lastModel && <span>model: {lastModel}</span>}
            <span>{TOKEN ? '🔒 authed' : '⚠ no token'}</span>
          </div>
        </div>
      </div>
    </>
  )
}
